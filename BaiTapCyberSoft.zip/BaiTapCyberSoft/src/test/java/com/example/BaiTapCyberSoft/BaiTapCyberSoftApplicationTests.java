package com.example.BaiTapCyberSoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaiTapCyberSoftApplicationTests {

	@Test
	void contextLoads() {
	}

}
